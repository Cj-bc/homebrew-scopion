/**
* @file config.hpp
*
* (c) copyright 2017 coord.e
*
* This file is part of scopion.
*
* scopion is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* scopion is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.

* You should have received a copy of the GNU General Public License
* along with scopion.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef SCOPION_CONFIG_HPP_
#define SCOPION_CONFIG_HPP_

#define SCOPION_VERSION_MAJOR 0
#define SCOPION_VERSION_MINOR 0
#define SCOPION_VERSION_PATCH 3
#define SCOPION_VERSION_TWEAK 1
#define SCOPION_VERSION "0.0.3.1"

#define SCOPION_COMPILED_COMPILER "@@HOMEBREW_PREFIX@@/Homebrew/Library/Homebrew/shims/super/clang++"
#define SCOPION_COMPILED_SYSTEM "Darwin-17.4.0"
#define SCOPION_COMPILED_GENERATOR "Unix Makefiles"
#define SCOPION_COMPILED_COMMIT_HASH ""
#define SCOPION_COMPILED_BRANCH ""

#define SCOPION_CACHE_DIR ".scopion"
#define SCOPION_ETC_DIR "@@HOMEBREW_PREFIX@@/Cellar/scopion/0.0.3.1/etc/scopion"

#endif
